# Responsive Portfolio — Demo

This is a small responsive portfolio template you can run locally. It includes:
- Sections: Home, About, Projects, Skills, Contact
- Responsive navigation with small-screen toggle
- Project cards with accessible modal details
- Animated skill bars (when scrolled into view)
- Contact form with client-side validation (no server)
- Clean, modern design and accessible markup

## How to run locally
1. Unzip `portfolio_project.zip` and open `index.html` in a browser.
2. Or run a local static server (recommended for best results):
   - Python 3: `python -m http.server 8000` then open `http://localhost:8000`
   - Or use VS Code Live Server extension.

## Customize
- Replace the placeholder images with your own in the `index.html` (or host images locally).
- Update links (GitHub/Email) in the contact section.
- Add resume.pdf to the project folder and update the resume link in `index.html`.

