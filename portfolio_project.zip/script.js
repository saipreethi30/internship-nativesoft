// Simple JS for navigation, modal, contact form validation, skill animations
document.addEventListener('DOMContentLoaded', function(){
  // Toggle nav on small screens
  const navToggle = document.getElementById('nav-toggle');
  const nav = document.getElementById('nav');
  navToggle.addEventListener('click', () => {
    const open = nav.getAttribute('data-open') === 'true';
    navToggle.setAttribute('aria-expanded', String(!open));
    nav.style.display = open ? '' : 'flex';
    nav.setAttribute('data-open', String(!open));
  });

  // Year
  document.getElementById('year').textContent = new Date().getFullYear();

  // Skill bars animation when in view
  const skillFills = document.querySelectorAll('.skill-fill');
  const obs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        const fill = entry.target;
        const pct = fill.getAttribute('data-fill') || 0;
        fill.style.width = pct + '%';
        obs.unobserve(fill);
      }
    });
  }, {threshold:0.3});
  skillFills.forEach(f => obs.observe(f));

  // Project modal open
  const cards = document.querySelectorAll('.project-card');
  const modal = document.getElementById('project-modal');
  const modalTitle = document.getElementById('modal-title');
  const modalDesc = document.getElementById('modal-desc');
  const modalLinks = document.getElementById('modal-links');
  const modalClose = document.getElementById('modal-close');

  cards.forEach(card => {
    const handler = () => {
      modalTitle.textContent = card.dataset.title || 'Project';
      modalDesc.textContent = card.dataset.desc || '';
      const link = card.dataset.links || '#';
      modalLinks.href = link;
      modalLinks.textContent = link === '#' ? 'No link' : 'Open Link';
      modal.setAttribute('aria-hidden','false');
      document.body.style.overflow = 'hidden';
    };
    card.addEventListener('click', handler);
    card.addEventListener('keypress', (e) => { if(e.key === 'Enter' || e.key === ' ') handler(); });
  });
  modalClose.addEventListener('click', () => { modal.setAttribute('aria-hidden','true'); document.body.style.overflow = ''; });

  // Close modal when clicking outside content
  modal.addEventListener('click', (e) => {
    if(e.target === modal) { modal.setAttribute('aria-hidden','true'); document.body.style.overflow = ''; }
  });

  // Contact form validation & "send"
  const form = document.getElementById('contact-form');
  const result = document.getElementById('form-result');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    // Basic HTML5 validation will run; we'll do extra checks
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const message = form.message.value.trim();
    if(name.length < 2){ result.textContent = 'Please enter a valid name.'; result.style.color='crimson'; return; }
    if(!/^\S+@\S+\.\S+$/.test(email)){ result.textContent = 'Please enter a valid email.'; result.style.color='crimson'; return; }
    if(message.length < 10){ result.textContent = 'Message is too short.'; result.style.color='crimson'; return; }

    // simulate sending
    result.style.color='var(--accent)';
    result.textContent = 'Thanks! Your message was sent (simulated).';
    form.reset();
  });

  // Resume download link - placeholder
  const downloadResume = document.getElementById('download-resume');
  downloadResume.addEventListener('click', (e) => {
    e.preventDefault();
    alert('Resume download is a placeholder in this demo. Add your resume.pdf to the project and update the link.');
  });

  // Accessibility: close modal with ESC
  document.addEventListener('keydown', (e) => {
    if(e.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false'){
      modal.setAttribute('aria-hidden','true');
      document.body.style.overflow = '';
    }
  });
});
